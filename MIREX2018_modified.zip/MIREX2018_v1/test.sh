#!/usr/bin/env bash
pwd
