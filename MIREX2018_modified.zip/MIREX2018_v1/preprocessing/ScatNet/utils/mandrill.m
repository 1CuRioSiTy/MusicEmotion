function f=mandrill()
f  = imreadBW('mandrill.png');
 end
