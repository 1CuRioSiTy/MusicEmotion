function x = uiuc_sample
    x = imreadBW('uiuc_example.jpg');
end